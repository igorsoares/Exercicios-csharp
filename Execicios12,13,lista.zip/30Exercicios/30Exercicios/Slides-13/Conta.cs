﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _30Exercicios.Slides_13
{
    class Conta
    {
        public string titular { get; set; }
        public int numero { get; set; }
        public decimal valor { get; set; }
        public string metodo { get; set; } // sacou / depositou
        public decimal digitado { get; set; }

    }
}
