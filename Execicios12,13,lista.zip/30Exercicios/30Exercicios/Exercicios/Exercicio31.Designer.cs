﻿namespace _30Exercicios.Exercicios
{
    partial class Exercicio31
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCarro1N = new System.Windows.Forms.TextBox();
            this.tbCarro1k = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCarro2k = new System.Windows.Forms.TextBox();
            this.tbCarro2N = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbCarro3k = new System.Windows.Forms.TextBox();
            this.tbCarro3N = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbCarro4k = new System.Windows.Forms.TextBox();
            this.tbCarro4N = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbCarro5k = new System.Windows.Forms.TextBox();
            this.tbCarro5N = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.listResults = new System.Windows.Forms.ListBox();
            this.btCalculo = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(257, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Consumo combustível";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbCarro5k);
            this.groupBox1.Controls.Add(this.tbCarro5N);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbCarro4k);
            this.groupBox1.Controls.Add(this.tbCarro4N);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbCarro3k);
            this.groupBox1.Controls.Add(this.tbCarro3N);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbCarro2k);
            this.groupBox1.Controls.Add(this.tbCarro2N);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbCarro1k);
            this.groupBox1.Controls.Add(this.tbCarro1N);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(13, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(242, 200);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Carro 1:";
            // 
            // tbCarro1N
            // 
            this.tbCarro1N.Location = new System.Drawing.Point(62, 41);
            this.tbCarro1N.Name = "tbCarro1N";
            this.tbCarro1N.Size = new System.Drawing.Size(63, 20);
            this.tbCarro1N.TabIndex = 1;
            // 
            // tbCarro1k
            // 
            this.tbCarro1k.Location = new System.Drawing.Point(145, 41);
            this.tbCarro1k.Name = "tbCarro1k";
            this.tbCarro1k.Size = new System.Drawing.Size(63, 20);
            this.tbCarro1k.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nome";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(162, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Km/L";
            // 
            // tbCarro2k
            // 
            this.tbCarro2k.Location = new System.Drawing.Point(145, 67);
            this.tbCarro2k.Name = "tbCarro2k";
            this.tbCarro2k.Size = new System.Drawing.Size(63, 20);
            this.tbCarro2k.TabIndex = 7;
            // 
            // tbCarro2N
            // 
            this.tbCarro2N.Location = new System.Drawing.Point(62, 67);
            this.tbCarro2N.Name = "tbCarro2N";
            this.tbCarro2N.Size = new System.Drawing.Size(63, 20);
            this.tbCarro2N.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Carro 2:";
            // 
            // tbCarro3k
            // 
            this.tbCarro3k.Location = new System.Drawing.Point(145, 93);
            this.tbCarro3k.Name = "tbCarro3k";
            this.tbCarro3k.Size = new System.Drawing.Size(63, 20);
            this.tbCarro3k.TabIndex = 10;
            // 
            // tbCarro3N
            // 
            this.tbCarro3N.Location = new System.Drawing.Point(62, 93);
            this.tbCarro3N.Name = "tbCarro3N";
            this.tbCarro3N.Size = new System.Drawing.Size(63, 20);
            this.tbCarro3N.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Carro 3:";
            // 
            // tbCarro4k
            // 
            this.tbCarro4k.Location = new System.Drawing.Point(145, 120);
            this.tbCarro4k.Name = "tbCarro4k";
            this.tbCarro4k.Size = new System.Drawing.Size(63, 20);
            this.tbCarro4k.TabIndex = 13;
            // 
            // tbCarro4N
            // 
            this.tbCarro4N.Location = new System.Drawing.Point(62, 120);
            this.tbCarro4N.Name = "tbCarro4N";
            this.tbCarro4N.Size = new System.Drawing.Size(63, 20);
            this.tbCarro4N.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Carro 4:";
            // 
            // tbCarro5k
            // 
            this.tbCarro5k.Location = new System.Drawing.Point(145, 149);
            this.tbCarro5k.Name = "tbCarro5k";
            this.tbCarro5k.Size = new System.Drawing.Size(63, 20);
            this.tbCarro5k.TabIndex = 16;
            // 
            // tbCarro5N
            // 
            this.tbCarro5N.Location = new System.Drawing.Point(62, 149);
            this.tbCarro5N.Name = "tbCarro5N";
            this.tbCarro5N.Size = new System.Drawing.Size(63, 20);
            this.tbCarro5N.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Carro 5:";
            // 
            // listResults
            // 
            this.listResults.FormattingEnabled = true;
            this.listResults.Location = new System.Drawing.Point(261, 42);
            this.listResults.Name = "listResults";
            this.listResults.Size = new System.Drawing.Size(423, 199);
            this.listResults.TabIndex = 2;
            this.listResults.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btCalculo
            // 
            this.btCalculo.Location = new System.Drawing.Point(215, 256);
            this.btCalculo.Name = "btCalculo";
            this.btCalculo.Size = new System.Drawing.Size(243, 23);
            this.btCalculo.TabIndex = 3;
            this.btCalculo.Text = "Calcular";
            this.btCalculo.UseVisualStyleBackColor = true;
            this.btCalculo.Click += new System.EventHandler(this.btCalculo_Click);
            // 
            // Exercicio31
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 291);
            this.Controls.Add(this.btCalculo);
            this.Controls.Add(this.listResults);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Exercicio31";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exercicio31";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbCarro5k;
        private System.Windows.Forms.TextBox tbCarro5N;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbCarro4k;
        private System.Windows.Forms.TextBox tbCarro4N;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbCarro3k;
        private System.Windows.Forms.TextBox tbCarro3N;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCarro2k;
        private System.Windows.Forms.TextBox tbCarro2N;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbCarro1k;
        private System.Windows.Forms.TextBox tbCarro1N;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listResults;
        private System.Windows.Forms.Button btCalculo;
    }
}