﻿namespace _30Exercicios
{
    partial class Exercicio13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbVala = new System.Windows.Forms.TextBox();
            this.tbValb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbValc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btSegundograu = new System.Windows.Forms.Button();
            this.tbX1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbX2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbDelta = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(171, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Exercício 13";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Valor a";
            // 
            // tbVala
            // 
            this.tbVala.Location = new System.Drawing.Point(69, 37);
            this.tbVala.Name = "tbVala";
            this.tbVala.Size = new System.Drawing.Size(100, 20);
            this.tbVala.TabIndex = 2;
            // 
            // tbValb
            // 
            this.tbValb.Location = new System.Drawing.Point(69, 66);
            this.tbValb.Name = "tbValb";
            this.tbValb.Size = new System.Drawing.Size(100, 20);
            this.tbValb.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Valor b";
            // 
            // tbValc
            // 
            this.tbValc.Location = new System.Drawing.Point(69, 101);
            this.tbValc.Name = "tbValc";
            this.tbValc.Size = new System.Drawing.Size(100, 20);
            this.tbValc.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Valor c";
            // 
            // btSegundograu
            // 
            this.btSegundograu.Location = new System.Drawing.Point(15, 141);
            this.btSegundograu.Name = "btSegundograu";
            this.btSegundograu.Size = new System.Drawing.Size(412, 23);
            this.btSegundograu.TabIndex = 7;
            this.btSegundograu.Text = "Calcular segundo grau";
            this.btSegundograu.UseVisualStyleBackColor = true;
            this.btSegundograu.Click += new System.EventHandler(this.btSegundograu_Click);
            // 
            // tbX1
            // 
            this.tbX1.Location = new System.Drawing.Point(302, 63);
            this.tbX1.Name = "tbX1";
            this.tbX1.ReadOnly = true;
            this.tbX1.Size = new System.Drawing.Size(59, 20);
            this.tbX1.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(258, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "x 1 :";
            // 
            // tbX2
            // 
            this.tbX2.Location = new System.Drawing.Point(302, 101);
            this.tbX2.Name = "tbX2";
            this.tbX2.ReadOnly = true;
            this.tbX2.Size = new System.Drawing.Size(59, 20);
            this.tbX2.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(258, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "x 2 :";
            // 
            // tbDelta
            // 
            this.tbDelta.Location = new System.Drawing.Point(302, 34);
            this.tbDelta.Name = "tbDelta";
            this.tbDelta.ReadOnly = true;
            this.tbDelta.Size = new System.Drawing.Size(59, 20);
            this.tbDelta.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(253, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Delta";
            // 
            // Exercicio13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 176);
            this.Controls.Add(this.tbDelta);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbX2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbX1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btSegundograu);
            this.Controls.Add(this.tbValc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbValb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbVala);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Exercicio13";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exercicio13";
            this.Load += new System.EventHandler(this.Exercicio13_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbVala;
        private System.Windows.Forms.TextBox tbValb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbValc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btSegundograu;
        private System.Windows.Forms.TextBox tbX1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbX2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbDelta;
        private System.Windows.Forms.Label label7;
    }
}