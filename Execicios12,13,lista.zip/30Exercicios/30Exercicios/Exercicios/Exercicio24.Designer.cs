﻿namespace _30Exercicios
{
    partial class Exercicio24
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.tbSalto1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSalto2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbSalto3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbSalto4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSalto5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.listResults = new System.Windows.Forms.ListBox();
            this.btProcessar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(139, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Competição de salto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome";
            // 
            // tbNome
            // 
            this.tbNome.Location = new System.Drawing.Point(113, 49);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(100, 20);
            this.tbNome.TabIndex = 2;
            // 
            // tbSalto1
            // 
            this.tbSalto1.Location = new System.Drawing.Point(113, 85);
            this.tbSalto1.Name = "tbSalto1";
            this.tbSalto1.Size = new System.Drawing.Size(100, 20);
            this.tbSalto1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Salto N1";
            // 
            // tbSalto2
            // 
            this.tbSalto2.Location = new System.Drawing.Point(113, 125);
            this.tbSalto2.Name = "tbSalto2";
            this.tbSalto2.Size = new System.Drawing.Size(100, 20);
            this.tbSalto2.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Salto N2";
            // 
            // tbSalto3
            // 
            this.tbSalto3.Location = new System.Drawing.Point(113, 164);
            this.tbSalto3.Name = "tbSalto3";
            this.tbSalto3.Size = new System.Drawing.Size(100, 20);
            this.tbSalto3.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Salto N3";
            // 
            // tbSalto4
            // 
            this.tbSalto4.Location = new System.Drawing.Point(113, 202);
            this.tbSalto4.Name = "tbSalto4";
            this.tbSalto4.Size = new System.Drawing.Size(100, 20);
            this.tbSalto4.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Salto N4";
            // 
            // tbSalto5
            // 
            this.tbSalto5.Location = new System.Drawing.Point(113, 237);
            this.tbSalto5.Name = "tbSalto5";
            this.tbSalto5.Size = new System.Drawing.Size(100, 20);
            this.tbSalto5.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Salto N5";
            // 
            // listResults
            // 
            this.listResults.FormattingEnabled = true;
            this.listResults.Location = new System.Drawing.Point(219, 46);
            this.listResults.Name = "listResults";
            this.listResults.Size = new System.Drawing.Size(196, 212);
            this.listResults.TabIndex = 13;
            // 
            // btProcessar
            // 
            this.btProcessar.Location = new System.Drawing.Point(46, 272);
            this.btProcessar.Name = "btProcessar";
            this.btProcessar.Size = new System.Drawing.Size(133, 23);
            this.btProcessar.TabIndex = 14;
            this.btProcessar.Text = "Processar";
            this.btProcessar.UseVisualStyleBackColor = true;
            this.btProcessar.Click += new System.EventHandler(this.btProcessar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(210, 272);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Exercicio24
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 307);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btProcessar);
            this.Controls.Add(this.listResults);
            this.Controls.Add(this.tbSalto5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbSalto4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbSalto3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbSalto2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbSalto1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Exercicio24";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exercicio24";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.TextBox tbSalto1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSalto2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbSalto3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbSalto4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbSalto5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox listResults;
        private System.Windows.Forms.Button btProcessar;
        private System.Windows.Forms.Button button1;
    }
}