﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _30Exercicios
{
    class Exercicio22_class
    {

        public int codigo { get; set; }
        public decimal altura { get; set; }
        public decimal peso { get; set; }


    }
}
